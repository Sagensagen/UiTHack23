#define kcmBackSpace		kcBackSpace
#define kcmNewLine		kcNewLine
#define kcmReturn		kcReturn
#define kcmNewPage		kcPageBreak
#define kcmNonBreakHyphen	kcNonBreakHyphen
#define kcmNonBreakSpace	kcNonBreakSpace
#define kcmNonReqHyphen		kcNonReqHyphen
#define kcmDelNext		kcDelNext
